 $(function(){
		
                        var $table = $('#fixTable'),         //table reference
                        // define pager options
                        pagerOptions = {

                                container: $(".pager"),
                                output: '{startRow} - {endRow} / {filteredRows} ({totalRows})',
                                fixedHeight: true,
                                // go to page selector - select dropdown that sets the current page
                                cssGoto: '.gotoPage'
                        };

        	// Initialize tablesorter
                $table
                        .tablesorter({
                                        theme: 'blue',
                                        headerTemplate : '{content} {icon}',
                                        widthFixed: true,
                                        showProcessing: true,
                                        widgets: ['zebra', 'filter'],  //'scroller','stickyHeaders'
                                        sortList:[[0,0],[1,0]]       //sort first and second Columns
				        
					/*
                                        widgetOptions:{
                                                scroller_upAfterSort: true,
                                                scroller_jumpToHeader: true,
                                                scroller_height:200,
                                                scroller_fixedColumns :0,
                                                stickyHeaders: "tablesorter-stickyHeader"
                                        }*/
                })

                // initialize the pager 
                .tablesorterPager(pagerOptions);

                $(".tablesorter-filter-row tablesorter-ignoreRow").remove();    
               
		//searching in table
		/*
                $('#searchBtn').click(function(){
				var input, filter, table, tr, td, i;
                                input = document.getElementById("searchFor"); //textbox input
                                filter = input.value.toUpperCase();
                                document.getElementById("searchFor").value = ""; //make empty
                                if(filter){
                                        table = document.getElementById("sortTbl");  
                                        tr = table.getElementsByTagName("tr"); //all rows in table
                                        
                                        for (i = 0; i < tr.length; i++) {
                                                td = tr[i].getElementsByTagName("td")[0];    //first column                                                   
                                                if (td) {
                                                        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                                                
                                                                tr[i].style.display = "";
                                                
                                                        } 
                                                        else {
                                                                tr[i].style.display = "none";
                                                                
                                                        }
                                                }                                              
                                        }
                                }
                        
                });

		 var r, $row, num = 52,
                row = '<tr class="rmRow"><td>Student{i}</td><td>{m}</td><td>{g}</td><td>{r}</td><td>{r}</td><td>{r}</td><td>{r}</td></tr>' +
        '<tr class="rmRow"><td>Student{j}</td><td>{m}</td><td>{g}</td><td>{r}</td><td>{r}</td><td>{r}</td><td>{r}</td></tr>';
                $('#AddBtn').click(function(){
                        
        
                        r = row.replace(/\{[gijmr]\}/g, function(m){
                                return {
                                        '{i}' : num + 1,
                                        '{j}' : num + 2,
                                        '{r}' : Math.round(Math.random() * 100),
                                        '{g}' : Math.random() > 0.5 ? 'male' : 'female',
                                        '{m}' : Math.random() > 0.5 ? 'Mathematics' : 'Languages'
                                }[m];
                        });
                        num = num + 2;
                        $row = $(r);
                        $('#sortTbl').find('tbody').append($row).trigger('update',[$row]);
                      
                });
		$('#RemoveBtn').click(function(){
			var t = $('#sortTbl');
                        var table = document.getElementById('sortTbl');
                        var tr = table.getElementsByTagName('tr');
                        var trLen = tr.length;
			$('.rmRow').remove();
			t.trigger('update');
                        return false;
                        //var r=$('#sortTbl').find(tr[4]).remove();

                });
                
               // update triger('update') white updating table to avoid sorting issue
                $('#RemoveBtn').click(function(){
                
                        var t = $('#sortTbl');
                        // disabling the pager will restore all table rows
                        // t.trigger('disablePager');
                        // remove chosen row
                        var table = document.getElementById('sortTbl');
                        var tr = table.getElementsByTagName('tr');

                        var r=$('#sortTbl').find(tr[4]).remove();
                
                        // restore pager
                        // t.trigger('enablePager');
                        t.trigger('update');
                        return false;
                }); */
                                
});
