<html>
<head>
	<script src="js/jquery-latest.min.js"></script>
        <script src="js/jspdf.min.js"></script>
        <script src="js/jspdf.plugin.autotable.js"></script>
	<script src="js/headerImg.js"></script>
	
</head>
<body>
	<button id="pdfBtn">PDF</button>
	<table id="exp">
		<thead>
			<th>Col1</th>
			<th>Col1</th>
		</thead>
		<tbody>
		<?php
		for($i=0;$i< 300;$i++)
		{
		?>
		<tr>
			<td>1</td>
			<td>2</td>
		</tr>
		<?
		}
		?>
		</tbody>
	</table>
<script>
	$(document).ready(function(){
		$('#pdfBtn').click(function(){
			var dateTime = Date();
			var pdfObj = new jsPDF('p', 'pt', 'a4');
			var totalPagesExp = "{total_pages_count_string}";
		
			//pdfObj.addImage(leftimg,'JPEG',11,10,300,40);
			//pdfObj.addImage(rightImg,'JPEG',300,10,285,40);
			console.log(leftimg);
			var TableElem = document.getElementById('exp');
        		var res = pdfObj.autoTableHtmlToJson(TableElem);
				
			var header = function(data) {
    					pdfObj.setFontSize(12);
    					pdfObj.setTextColor(40);
    					pdfObj.setFontStyle('normal');
    					pdfObj.addImage(leftimg, 'JPEG', data.settings.margin.left, 20, 50, 50);
					pdfObj.addImage(middleImg,'JPEG',66,20,285,50);
					pdfObj.text('eScan VAPT Report',100,40);
					pdfObj.setFontSize(9);
					pdfObj.text(dateTime,80,55);
					pdfObj.addImage(rightImg,'JPEG',260,20,315,50);
    					//pdfObj.text(" Report Header", data.settings.margin.left, 50);
					console.log(data.settings.margin.left); 
  				}
			//console.log(data.settings.margin.left);			

			//pdfObj.autoTable(res.columns,res.data,{startY:50,margin: {top: 10, left: 10, right: 10, bottom:10},styles:{ overflow: 'linebreak'}});
			//pdfObj.addPage();
			 pdfObj.autoTable(res.columns,res.data,{beforePageContent: header,startY:70,margin: {top:70,left: 20,right:20}});
			pdfObj.save("sample.pdf");
			
		});
	});
</script>
</body>
</html>
