<html><head>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<!--link href="/emcwebadmin/Stylesheet/escan-style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" src="/emcwebadmin/JavaScripts/ewconsole.js"></script-->
<!--<link rel="stylesheet" type="text/css" href="Time.css"/>      calling time.css -->
<!--<script type="text/javascript" src="graphColor.js"></script>  Calling graphColor.js file -->
<style>
*{font-size:11px;}
table#timesheet{
	border			: 0px solid #808080;
	border-collapse	: collapse;
	margin			: 0 8 0 8;	/* top right bottom left */
}
table#timesheet td{
	border		: 1px solid grey;	/* width style color */
	font-size	: 15px;
	height		: 20px;
	width		: 10px;			
}
table#time{
	border-collapse	: collapse;
}
#tblOptions label{
	font-Weight		: bold;
}
</style>
<script type="text/javascript">
// variable used for get the onmousedown and onmouseup event
var flag;
var downRow;
var downColumn;
var state			= "0";
var EnableDisable	= "1";
var AccessArray		= new Array(7);
// default StateCode
/*var StateCode	= "000000000000000000000000000000000000000000000000,"+
				  "000000000000000000000000000000000000000000000000,"+
				  "000000000000000000000000000000000000000000000000,"+
				  "000000000000000000000000000000000000000000000000,"+
				  "000000000000000000000000000000000000000000000000,"+
				  "000000000000000000000000000000000000000000000000,"+
				  "000000000000000000000000000000000000000000000000";
					*/					

var ColorCode	= new Array("#006a35","#0000b3","#d20000"); /* green,blue,red */

// define cell state array
var stateArray	= new Array(2)

for (i=0; i <7; i++){
	stateArray [i]	= new Array(48);
	}

// function for get the color according to the StateCode
function getColor(){
	//var get   = StateCode.split(",",7);
	var cellObj;

	// array initialization
	for(var i=0; i<=6; i++){
		for(var j=0; j<=47; j++){
			
			stateArray[i][j] = AccessArray[i].split("")[j]; //Assign state to array 
			
			cellObj	= document.getElementById("timesheet").rows[i].cells[j];
			cellObj.style.backgroundColor = ColorCode[stateArray[i][j]];	// Set COlor
			cellObj.setAttribute("state",stateArray[i][j]);	// Set state to cell as an attribute
		}
	}
}

//function for enable/disable the radio button
function DisabledControl(state){
	for(var i = 0; i <3; i++){
		document.formRadio.radio1[i].disabled = state;
		document.getElementById("GetButton").disabled = state; 
	}
	flag	= 0;
}

// function call on onload event for create state table and its respective events
//onload = function(){
function InitializeControl(EnableSchedule,WebAccess){
	//var  StateCode= '000000000000000000000000000000000000000000000000,000000000000000000000000000000000000000000000000,000000000000000000000000000000000000000000000000,000000000000000000000000000000000000000000000000,000000000000000000000000000000000000000000000000,000000000000000000000000000000000000000000000000,000000000000000000000000000000000000000000000000';
	var StateCode = document.getElementById('hdnState').value;
	
	disableSelection(document.body);  // calling function for disable the selection of page
	if (WebAccess!=""){
		StateCode	= WebAccess;
	}
	
	for (var i=0; i<7; i++){
		AccessArray[i]	= StateCode.split(",")[i];
	}
	
	if (EnableSchedule=="1"){
		document.getElementById("chkWebAccess").checked	= true;
		ControlTimePad(true);
	}else{
		document.getElementById("chkWebAccess").checked	= false;
		ControlTimePad(false);
	}
	addRows();						  // calling function for creat the table
	getColor(); 					  // calling fnction for color

	//var table = document.getElementsByTagName("div")[0];	// Track table of div tagName
	var table = document.getElementById("timesheet");
	var rows = table.getElementsByTagName("tr");			// Get all the rows in the table
	
	for (var i=0; i <rows.length; i++){					// Loop for get the row position in row
		var cells = rows[i].getElementsByTagName("td");		// Get the cells in the given row
		
		for (var j = 0; j <cells.length; j++){				// Loop for get the cell position
			var cell			= cells[j];
			cell.rowIndex		= i;
			cell.positionIndex	= j;
            
			// function will start selection with call compareValues function
			// and store first cell details in downRow and downColumn
			cell.onmousedown = function down(){
					
				flag		= 1;					// Set flag equls to 1 as selection start
				downRow		= this.rowIndex;        // assign selected row index to downRow variable
				downColumn	= this.positionIndex;   // assign selected column index to downRow variable 
			
			
				if (EnableDisable){
					compareValues(downRow,downColumn);  // function call for color selected range
				}
			}
			// function will call compareValues function as per mouse move for selection
			cell.onmouseover = function over(){
				
				if(flag == 1){
					var	Row    = this.rowIndex;
					var	Column = this.positionIndex;
					if (EnableDisable){				
						compareValues(Row,Column);
					}
				}
			}
			// function for retun to previous stage until click not get release
			cell.onmouseout = function out(){
				var cellobj;
				
				if (EnableDisable){  // if checkbox is checked
					if(flag == 1){
						var upRow = this.rowIndex;			// assign selected row index to upRow variable
						var upColumn = this.positionIndex;	// assign selected column index to upColumn variable
						
						// assign the color saved in array to the cell of table
						if(downRow >= upRow && downColumn > upColumn){
							for(var varRow = upRow; varRow <= downRow; varRow++){
								for(var varColumn = upColumn; varColumn <= downColumn; varColumn++){
									cellobj	= document.getElementById("timesheet").rows[varRow].cells[varColumn];
									cellobj.style.backgroundColor = ColorCode[stateArray[varRow][varColumn]];
									cellobj.setAttribute("state",stateArray[varRow][varColumn]);
								}
							}
						}
						else if(downRow <= upRow && downColumn <= upColumn){
							for(var varRow = downRow; varRow <= upRow; varRow++)  {
								for(var varColumn = downColumn; varColumn <= upColumn; varColumn++){
									cellobj	= document.getElementById("timesheet").rows[varRow].cells[varColumn];
									cellobj.style.backgroundColor = ColorCode[stateArray[varRow][varColumn]];
									cellobj.setAttribute("state",stateArray[varRow][varColumn]);
								}
							}
						}
						else if(downRow <upRow && downColumn >= upColumn){
							for(var varRow=downRow; varRow<=upRow; varRow++)  {
								for(var varColumn = upColumn; varColumn <= downColumn; varColumn++){
									cellobj	= document.getElementById("timesheet").rows[varRow].cells[varColumn];
									cellobj.style.backgroundColor = ColorCode[stateArray[varRow][varColumn]];
									cellobj.setAttribute("state",stateArray[varRow][varColumn]);
								}
							}
						}
						else{
							for(var varRow=upRow; varRow<=downRow; varRow++){
								for(var varColumn = downColumn; varColumn <= upColumn; varColumn++){
									cellobj	= document.getElementById("timesheet").rows[varRow].cells[varColumn];
									cellobj.style.backgroundColor = ColorCode[stateArray[varRow][varColumn]];
									cellobj.setAttribute("state",stateArray[varRow][varColumn]);
								}
							}
						}
					}
				}
			}
			// function for save the previous color of cell into the array stateArray[i][j]
			cell.onmouseup = function up(){
				flag = 0;
				//chkWebAccess.focus();  // for focus on mouseup
				for(var i=0; i<=6; i++){
					for(var j=0; j<=47; j++){ 
						// saving every cell's state value in array
						stateArray[i][j] = document.getElementById("timesheet").rows[i].cells[j].getAttribute("state");
					}
				}
			}
		}
	}
}

// function for stop the over and out function
function RejectSelection(){
	flag = 0;     
}

// function for color selected range
function compareValues(upRow,upColumn){
	
	if(downRow >= upRow && downColumn > upColumn){
		for(var varRow = upRow; varRow <= downRow; varRow++) {
			for(var varColumn = upColumn; varColumn <= downColumn; varColumn++){
				color(varRow,varColumn);   // calling the color function
			}
		}
	}
	else if(downRow <= upRow && downColumn <= upColumn){
		for(var varRow = downRow; varRow <= upRow; varRow++){
			for(var varColumn = downColumn; varColumn <= upColumn; varColumn++){
				color(varRow,varColumn);   // calling the color function
			}
		}
	}
	else if(downRow <upRow && downColumn >= upColumn){
		for(var varRow = downRow; varRow <= upRow; varRow++){
			for(var varColumn = upColumn; varColumn <= downColumn; varColumn++){
				color(varRow,varColumn);
			}
		}
	}
	else{
		for(var varRow = upRow; varRow <= downRow; varRow++){
			for(var varColumn = downColumn; varColumn <= upColumn; varColumn++){
				color(varRow,varColumn); 
			}
		}
	}
}

// function for fill the colors
function color(varRow,varColumn){
	var cellobj	= document.getElementById("timesheet").rows[varRow].cells[varColumn];
	cellobj.style.backgroundColor = ColorCode[state];
	cellobj.setAttribute("state",state);
}

function SetState(val){
	state	= val;
}
// function for prevent the screen selection
function disableSelection(target){
	if (typeof target.onselectstart!="undefined") //IE 
		target.onselectstart=function(){return false}
	else if (typeof target.style.MozUserSelect!="undefined") //Firefox 
		target.style.MozUserSelect="none"
	else //All other ie: Opera
		target.onmousedown=function(){return false}
		
	target.style.cursor = "default";
}

// function for add row and column dynamically
function addRows(){
    var tblObj = document.getElementById("timesheet");
    var tbodyObj = tblObj.getElementsByTagName("tbody")[0];
	for(var i=0; i<=6; i++){
	    var trObj = document.createElement("tr");
		for(var j =0; j<=47; j++){
			var tdObj = document.createElement("td");
			//TD.innerHTML = "&nbsp;";
			trObj.appendChild (tdObj);
		}
		tbodyObj.appendChild(trObj);
    }
}

// function for give the code to cell according to color
function GetInterval(){
	var ResultAccess	= '';	
	for(var i=0; i<=6; i++){
		for(var j=0; j<=47; j++){
			ResultAccess = ResultAccess + stateArray[i][j];
		}
		if (i<6)
			ResultAccess =  ResultAccess + ',';
	}
	return ResultAccess;	
}
function SetTimeRestrictionForApplCtrl(){
	try{
		document.getElementById("lblWebAccess").style.display		= "none";
		document.getElementById("lblEnabled").style.display			= "inline";
		
		document.getElementById("trActInActBlock").style.display	= "none";
		document.getElementById("trEnableDisable").style.display	= "inline";
		
		document.getElementById("rdoEnabled").checked				= true;
	}catch(e){}
}
function ControlTimePad(state){

	EnableDisable	= (state==true)?1:0;
	document.getElementById("tblOptions").disabled = !state;
	EnableDisableTable("tblOptions",!state);
	EnableDisableTable("daytimesheet",!state);
	//SetDisabled();
}
function EnableDisableTable(objid,state){
	var tblObj	= document.getElementById(objid);
	if (tblObj!=null){
		tblObj.disabled = state;
		var elobj	= tblObj.getElementsByTagName("*");
		
		for(var i=0; i<elobj.length; i++){
			try{
				if ((elobj[i]!=null)||(elobj[i]!=undefined)){
					elobj[i].disabled = state;
				}
			}catch(e){}
		}
	}
}
function EnableDisabledControl(enablestate){
	if (enablestate==true){
		document.getElementById("chkWebAccess").disabled	= false;
		document.getElementById("lblWebAccess").disabled	= false;
		document.getElementById("lblEnabled").disabled		= false;
		ControlTimePad(document.getElementById("chkWebAccess").checked);
	}else if (enablestate==false){
		document.getElementById("chkWebAccess").disabled	= true;
		document.getElementById("lblWebAccess").disabled	= true;
		document.getElementById("lblEnabled").disabled		= true;
		ControlTimePad(false);
	}
}
//function to get statusCode rowise
function getRowValue(){

	var outPutArray = [];
	var table = document.getElementById('timesheet'); //get table referrence
	var row = table.getElementsByTagName('tr'); // get Table rows
	var finalVal = "";
	var State = "";
	for(var k = 0; k < row.length; k++){
		var col = row[k].getElementsByTagName("td"); // get table columns
		for(var j = 0; j < col.length; j++){
			
			var val = col[j].getAttribute('state'); //get state attribute of each column 	
			 finalVal = finalVal + val;
			 
		}
		outPutArray.push(finalVal); 
		finalVal = ""; // make blank each time to avoid replication
	}
	State = outPutArray.join(","); //array to string

	
	/*
	document.getElementById('hdnState').remove();
	var ref = document.getElementById('frmTimeRestriction');
	var hdnElem = document.createElement("input");
	hdnElem.setAttribute('type','hidden');
	hdnElem.setAttribute('id','hdnState');
	
	ref.appendChild(hdnElem);	
	document.getElementById('hdnState').value =  State;
	//localStorage.removeItem("StateCode1");
	localStorage.setItem("StateCode1", State);
        var StateCode  = localStorage.getItem("StateCode1");
	
	
	 document.getElementById('hdnState').value =  State;
	 localStorage.setItem("StateCode1", State);*/
	/*
	$.ajax({
		type:"POST",
		url:"writeStateCode",
		data:{"code":State},
		success:function(resp){
			
		}
	});*/
	//ajax call to updaet StateCode
	 var xmlhttp = new XMLHttpRequest();
 	 xmlhttp.open("GET","writeStateCode.php?code="+State,true);
 	 xmlhttp.send();
	/*
	xmlhttp.onreadystatechange=function()
      	{
      		if (xmlhttp.readyState==4 && xmlhttp.status==200)
        	{
        		console.log("RESP="+xmlhttp.responseText);
        	}
      	}
	*/
}
var enable = 0;
function EnableSaveBtn(){
	
	if( enable%2 == 0)
	{
		document.getElementById('saveBtn').disabled = false;
	}
	else{
		document.getElementById('saveBtn').disabled = true;
	
	}
	enable = enable +1;
	
}
</script>
</head>

<body class="lightbg" style="cursor: default;" onload="InitializeControl(0,'');">
<form id="frmTimeRestriction" autocomplete="off">
	<table>
	<tbody><tr>
		<td style="width:3"></td>
		<td style="height:10"></td>
		<td style="width:3"></td>
	</tr>
	<tr>
		<td style="width:3"></td>
		<td style="height:10">
			<input id="chkWebAccess" onclick="ControlTimePad(this.checked);EnableSaveBtn();" checked="" type="checkbox" style="vertical-align:middle;">
			<label id="lblWebAccess" for="chkWebAccess">Enable Time Restrictions for Web Access</label>
			<label id="lblEnabled" for="chkWebAccess" style="display:none">Enable</label>
		</td>
		<td style="width:3"></td>
	</tr>
	<tr>
		<td style="width:3"></td>
		<td style="height:10"></td>
		<td style="width:3"></td>
	</tr>
	<tr>
		<td style="width:3"></td>
		<td style="height:10">
			<fieldset>
			<table id="tblPallete" border="0">
			<tbody><tr>
				<td style="width:3"></td>
				<td style="height:10"></td>
				<td style="width:3"></td>
			</tr>
			<tr>
				<td style="width:3"></td>
				<td>
					<table id="daytimesheet" border="0" width="100%"> <!-- table for graph and days-->
						<tbody><tr>
							<td onmousemove="RejectSelection()"></td>
							<td onmousemove="RejectSelection()">
								<table id="time" onmousemove="RejectSelection()" cellspacing="0" cellpadding="0" border="0" width="100%"> <!-- time in hours -->
									<tbody>
										<tr>
										<td colspan="13" align="center">AM</td>
										<td colspan="12" align="center">PM</td>
										</tr>		
										<tr>
										<td style="border-bottom:2px solid grey">00</td> <td style="border-bottom:2px solid grey">01</td> <td style="border-bottom:2px solid grey">02</td> <td style="border-bottom:2px solid grey">03</td> 
<td style="border-bottom:2px solid grey">04</td> <td style="border-bottom:2px solid grey">05</td> <td style="border-bottom:2px solid grey">06</td> <td style="border-bottom:2px solid grey">07</td> 
<td style="border-bottom:2px solid grey">08</td> <td style="border-bottom:2px solid grey">09</td> <td style="border-bottom:2px solid grey">10</td> <td style="border-bottom:2px solid grey">11</td> 
<td style="">12</td> <td style="border-bottom:2px solid green">01</td> <td style="border-bottom:2px solid green">02</td> <td style="border-bottom:2px solid green">03</td> 
<td style="border-bottom:2px solid green">04</td> <td style="border-bottom:2px solid green">05</td> <td style="border-bottom:2px solid green">06</td> <td style="border-bottom:2px solid green">07</td> 
<td style="border-bottom:2px solid green">08</td> <td style="border-bottom:2px solid green">09</td> <td style="border-bottom:2px solid green">10</td> <td style="border-bottom:2px solid green">11</td> 
<td style="border-bottom:2px solid green">12</td>
									</tr>
								</tbody></table>
							</td>
						</tr>
						<tr>
							<td onmousemove="RejectSelection()">
								<table id="days" cellspacing="5" cellpadding="2" border="0"> <!-- table for days-->
									<tbody><tr><td nowrap="">Sunday</td></tr>
									<tr><td nowrap="">Monday</td></tr>
									<tr><td nowrap="">Tuesday</td></tr>
									<tr><td nowrap="">Wednesday</td></tr>
									<tr><td nowrap="">Thursday</td></tr>
									<tr><td nowrap="">Friday</td></tr>
									<tr><td nowrap="">Saturday</td></tr>
								</tbody></table>
							</td>
							<td>
								 <table id="timesheet" cellspacing="0" cellpadding="0" border="0" align="center">
									<tbody></tbody>
								  </table>
																</td>
						</tr>
						<tr>
							<td onmousemove="RejectSelection()"></td>
							<td onmousemove="RejectSelection()"></td>
						</tr>
					</tbody></table>
				</td>
				<td style="width:3"></td>
			</tr>
			<tr>
				<td style="width:3"></td>
				<td style="height:10" align="center">
				
					<table id="tblOptions">
					<tbody><tr id="trActInActBlock">
						<td style="width:5px;height:10px"></td>
						<td>
							<input id="rdoActive" name="permission" onclick="SetState(0)" checked="" type="radio" style="vertical-align:top;margin-top:-1px;">
							<label for="rdoActive" style="color:#006a35; font-weight:bold;">Active</label>
						</td>
						<td style="width:5px;height:10px"></td>
						<td>
							<input id="rdoInActive" name="permission" onclick="SetState(1)" type="radio" style="vertical-align:top;margin-top:-1px;">
							<label for="rdoInActive" style="color:#0000b3; font-weight:bold;">Inactive</label>
						</td>
						<td style="width:5px;height:10px"></td>
						<td>
							<input id="rdoBlock" name="permission" onclick="SetState(2)" type="radio" style="vertical-align:top;margin-top:-1px;">
							<label for="rdoBlock" style="color:#d20000; font-weight:bold;">Block Web Access</label> 
						</td>
						<td style="width:5px;height:10px"></td>
					</tr>
					<tr>
						<td>
						
						</td>
					</tr>
					<tr id="trEnableDisable" style="display:none">
						<td style="width:5px;height:10px"></td>
						<td>
							<input id="rdoEnabled" name="permission" onclick="SetState(0)" type="radio">
							<label for="rdoEnabled" style="color:#006a35; font-weight:bold;">Enabled</label>
						</td>
						<td style="width:5px;height:10px"></td>
						<td>
							<input id="rdoDisabled" name="permission" onclick="SetState(1)" type="radio">
							<label for="rdoDisabled" style="color:#0000b3; font-weight:bold;">Disabled</label> 
						</td>
						<td style="width:5px;height:10px"></td>
					</tr>
					</tbody></table>
				
				</td>
				<td style="width:3"></td>
			</tr>
			</tbody></table>
			</fieldset>
			<button id="saveBtn" onclick="getRowValue();return false;"disabled="">Save</button>
		</td>
		<td style="width:3"></td>
	</tr>
	</tbody></table>
	<input id="ControlEnabled" value="true" type="hidden">
	<input id="timeinterval" value="" type="hidden">
	<input id="enableschedule" value="0" type="hidden">
	<input id="hdnState" type="hidden" value="<? echo $file =file_get_contents('statecode.txt');?>"/>

</form></body></html>
