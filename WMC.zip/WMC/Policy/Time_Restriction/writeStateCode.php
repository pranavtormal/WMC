<?php
$stateCode = trim($_GET['code']); //webPro
$stateCode1 = trim($_GET['code1']);//endPoint
$file = 'statecode.txt';//webPro
$file1 = 'endstatecode.txt';
if($stateCode){
	file_put_contents($file,$stateCode);
}
else if($stateCode1){
	file_put_contents($file1,$stateCode1);
}

?>
