<?php

$case = trim($_POST['case']);
$rule_name = trim($_POST['rule_name']);
$option = trim($_POST['option']);
$xml = simplexml_load_file("firewall-rules.xml") or die("Error");
$length_of_xml = count($xml);

// Read All Name Attributea
function read_xml($xml)
{
	echo "<table height=\"380px\"  border=\"1\" width=\"100%\">";
        foreach($xml->children() as $rule)
        {
                $arr = $rule->attributes();
                $name = $arr['name'];
                echo "<tr>";
                echo "<td>";
                echo "<input class=\"check\" type=\"checkbox\" name=\"$name\"value=\"$name\"/>$name";
                echo "</td>";
                echo "</tr>";
        }
        echo "</table>";
}

if($rule_name != "")
{
	for($r=0;$r<$length_of_xml;$r++)
	{
		
		$ruleName = $xml->rule[$r]->attributes()->{'name'};
		if($ruleName == $rule_name)
		{	
			$node_to_delete = $xml->rule[$r-1]->attributes()->{'name'};
			$node = $xml->xpath("/firewall-rules/rule[@name='$node_to_delete']");
			if(! empty($node))
			{
				$xml_dom= dom_import_simplexml($xml);
				$dom = new DOMDocument();
				$xml_dom = $dom->importNode($xml_dom, true);
				$dom->appendChild($xml_dom);
				$xpath = new DOMXPath($dom);
				if($option == "ShiftUp")
				{     
					$name1 = $xml->rule[$r-1]->attributes()->{'name'};
				}
				else
				{
					$name1 = $xml->rule[$r+1]->attributes()->{'name'};
				}
				$name2 = $xml->rule[$r]->attributes()->{'name'};
				$nodeOne = $xpath->evaluate("//rule[@name='$name1']")->item(0);
				$nodeTwo = $xpath->evaluate("//rule[@name='$name2']")->item(0);
				if (!$nodeOne->isSameNode($nodeTwo)) 
				{
 					// remember parent and position of the second node
  					$parent = $nodeTwo->parentNode;
  					$target = $nodeTwo->nextSibling;
  					// move the second node
  					$nodeOne->parentNode->insertBefore($nodeTwo, $nodeOne->nextSibling);
					// move the first node
  					$parent->insertBefore($nodeOne, $target);
				}
        			$dom->preserveWhiteSpace = False;
        			$dom->formatOutput = True;
        			$dom->save("firewall-rules.xml");
				$xml1 = simplexml_load_file("firewall-rules.xml") or die("Error");
             
				read_xml($xml1); //call to function to display updates
			}
			break;
		}
	}
}

	
if($case == "readrule")
{	
	read_xml($xml);
}

?>
