<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="UTF-8">
	<style>
		.btn{
			margin-left:10px;
		}

		.outerDiv{
			height:auto;
		}

		.optionDiv{
			height:195px;
			width:940px;
			border:1px solid grey;
			margin-top:10px;
			background-color:#CCE5FF;
		}
	
		.blankGraphDiv{
			margin-top:2px;
			height:100%;
			width:945px;
		}

		.dragOptionTable{
                        width:100%;
                        border:1px;
                      
                }
	
		.userSelect{
			user-select:none;
			-moz-user-select:none;
			-webkit-user-select:none;
			-ms-user-select:none;
		}

		.dragOptionMainDiv{
                        width:800px;
                        height:190px;
                        border:1px solid grey;
                        margin:auto;
			overflow:hidden;
                }

		#Ulist li{
                        margin:auto;
                        list-style-type: none;
                        font-size:20px;
                        font-weight:bold;
                        margin-left:30px;
                        cursor:grab;
                        cursor:-moz-grab;
                        cursor:-webkit-grab;
                        cursor:-ms-grab;
                }
			
		th{
			background-color:#9999FF;
		}
		.pieTd{
				width:300px;
			
		
			}

	</style>
	<script src="jquery-1.7.1.min.js"></script>
        <script src="highcharts.js"></script>
	<script type="text/javascript">
                $(document).ready(function(){
                       
                        $.ajax({
                                type:'GET',
                                url:'joinData.php',
                                contentType:'appliaction/json',
                                dataType:'json',
                                data:{"case":0},
                                success:function(resp){
                        	
					var name_array = [];
					var price_array = [];
					var date_array = []; //contains duplicates values
					var unique_date = []; //for unique date
					var price = 0;
                                        var pie1_array = []; //array for price range 200 to 300
                                        var pie1_name = []; 
                                        var pie2_array = []; //array for price range 301 to 400
                                        var pie2_name = [];
                                        var pie3_array = []; //array for price range 401 to 500
                                        var pie3_name = []; 

					for(var i = 0; i < resp.id.length; i++)
					{
						var id = resp.id[i]['customer_id'];
						date_array.push(resp.id[i]['order_date']);
						$('#Ulist').append('<li draggable="true" ondragstart="drag(event)" id="'+ id +'">'+id+'<li>');
						
					}

					var unique_date = date_array.filter(function(ele,index,self){
						return index == self.indexOf(ele);
					});//remove duplicates
					
					for(var x = 0; x < unique_date.length; x++)
					{
						$('#dragOptionRightDiv').append('<center><input type="checkbox" onchange="getData()" style="vertical-align:middle;" class="check" value="'+unique_date[x]+'">'+unique_date[x]+'</center>');	
					}
					
					for(var j = 0; j < resp.bar.length; j++)
					{
						var price = parseInt(resp.bar[j]['price']);
						var name = resp.bar[j]['customer_name'];
						price_array.push(price);	 
						name_array.push(name);
						 if(price >= 200 && price <= 300) //filter price range
                                                 {
                                                      	pie1_array.push(price);   
                                                      	pie1_name.push(name);
                                                 }
                                                 else if(price >= 301 && price <= 400)
                                                 {
                                                 	pie2_array.push(price);
                                                        pie2_name.push(name);
                                                 }
                                                 else
                                                 {
                                                        pie3_array.push(price);
                                                        pie3_name.push(name);
                                                 }
					}

					 
					console.log(pie2_array);
					if(pie2_array.length > 0)
                                        {
                                        	id = $('#pie2Td');
                                                title = "Pie Chart";
                                                var data_array = [];
                                                for(var k = 0; k < pie2_array.length; k++)
                                                {
                                                	data_array.push({name:pie2_name[k],y:pie2_array[k]});
                                                }//insert dynamic object into array
                                                ydata = [{name:"Product price",data:data_array}];
                                                chartType = "pie";      
                                                drawHighChartBar(id,title,ydata,pie2_name,chartType,yAxis);
                                        }
                                        if(pie1_array.length > 0)
                                        {
                                        	id = $('#pie1Td');
                                                title = "Pie Chart";
                                                var data_array = [];
                                                for(var k = 0; k < pie1_array.length; k++)
                                                {
                                                	data_array.push({name:pie1_name[k],y:pie1_array[k]});
                                                                
                                                }
                                                ydata = [{name:"Product price",data:data_array}];
                                                chartType = "pie";      
                                               drawHighChartBar(id,title,ydata,pie1_name,chartType,yAxis);

                                         }					

					if(pie3_array.length > 0)
                                        {
                                        	id = $('#pie3Td');
                                                title = "Pie Chart";
                                                var data_array = [];
                                                for(var k = 0; k < pie3_array.length; k++)
                                                {
                                                	data_array.push({name:pie3_name[k],y:pie3_array[k]});
                                                                
                                                }//insert dynamic object into array
                                                ydata = [{name:"Product price",data:data_array}];
                                                chartType = "pie";      
                                               drawHighChartBar(id,title,ydata,pie3_name,chartType,yAxis);

                                         }

					function drawHighChartBar(id,Title,data,names,chartType,yAxis) //function to create Charts
                        		{
                                		$(id).highcharts({
                                        		chart:{
                                                		type:chartType,
                                              		      },
                                        		title:{
                                                		text:Title
                                              		      },
                                        		xAxis:{
                                                		categories:names,
							      },
                                        		yAxis,
                                       			legend:{
                                                		 reversed:true
                                              		       },
                                       			series:data
                                		 });
                        		} //drawHighChartBar function end here 

					var tid = $('#barGraphTd');
					var title = "Bar Graph";
					var chartType = "column";
					var yAxis =  {
                                                     	min:0,
                                                     	title:{
            							text:'Price (Rs)'
        						      }	
                                                     };

					var ydata = [{name:"Product Price",data:price_array}];

					drawHighChartBar(tid,title,ydata,name_array,chartType,yAxis);//function call for bar chart
					tid = $('#lineGraph');
					title = "Line Graph";
					chartType = "spline";
					drawHighChartBar(tid,title,ydata,name_array,chartType,yAxis);//function call for Line Chart
				    
                                }//success function end here
                        });//ajax end here
		
                });//ready function end here
	
		 function allowDrop(ev) 
                {
                         ev.preventDefault(); 
                }

                function drag(ev)
                {
                        ev.dataTransfer.setData("text", ev.target.id); 
                }

                function drop(ev) 
                {
                        ev.preventDefault();
                        var data = ev.dataTransfer.getData("text");
                        document.getElementById("drop").value += data + ','; 
                        document.getElementById(data).remove();                       
                }

		function drawHighChartBar(id,Title,data,names,chartType,yAxis)
                {
			//var hwidth = $(id).parent().width();
                	$(id).highcharts({
                        		chart:{
                                                type:chartType
					
						//wiidth:300
                                              },
					 plotOptions:{
        						pie:{
            							size: 150
        						    }
    						     },
                                        title:{
                                             	text:Title
                                              },
                                        xAxis:{
                                                categories:names,
                                              },
                                        yAxis,
                                    	legend:{
                                       		reversed:true
                                          	},
                                        series:data
                         });
                }
			
		function generateGraph()
		{
			var col = document.getElementById('drop').value;
                        document.getElementById("alertSpan").innerHTML = "";
			document.getElementById("drop").value = "";
			$('.check').attr('checked',false); 
                        var col = col.trim();

                        if(col)
                        {
                                var str = col.replace(/,\s*$/,""); //remove last ","
				var element = str.split(',');
		
				for(var k = 0; k < element.length ; k++) //append dropped element
				{
					 $('#Ulist').append('<li draggable="true" ondragstart="drag(event)" id="'+ element[k]+'">'+element[k]+'<li>');

				}

				$.ajax({
					type:'GET',
					url:'joinData.php',
					contentType:'appliaction/json',
					dataType:'json',
					data:{"case":1,"cid":str},
					success:function(response){
						//console.log(response);
						var barVal = '';
						$('.barType:checked').each(function(){
                                			var val = $(this).val();
                                			barVal += val+",";
                        			});
			
						var names_array = [];
						var price_array = [];

 						var price = 0;
						var pie1_array = [];
						var pie1_name = [];
						var pie2_array = [];
						var pie2_name = [];
						var pie3_array = [];
						var pie3_name = [];

						for(var i = 0; i < response.length; i++)
						{
							names_array.push(response[i]['customer_name']);
							price_array.push(parseInt(response[i]['price']));
							price = parseInt(response[i]['price']);
							
							if(price >= 200 && price <= 300)
							{
								pie1_array.push(price);	  
								pie1_name.push(response[i]['customer_name']);
							}
							else if(price >= 301 && price <= 400)
							{
								pie2_array.push(price);
								pie2_name.push(response[i]['customer_name']);
							}
							else
							{
								pie3_array.push(price);
								pie3_name.push(response[i]['customer_name']);
							}
						}
					
						var id = $('#barGraphTd');
						var title = "Bar Graph";
						var ydata = [{name:"Product Price",data:price_array}];
						var chartType = "column";
						var yAxis ={
								min:0,
								max:500,
								title:{
                                                                	text:'Price (Rs)'
                                                              	      } 
							   };

						drawHighChartBar(id,title,ydata,names_array,chartType,yAxis); //function call for bar chart
						id = $('#lineGraph');
						title = "Line Graph";
						chartType = "spline";
						drawHighChartBar(id,title,ydata,names_array,chartType,yAxis); // function call for Line Chart 
						
						//pieChart start here
						if(pie2_array.length > 0)
						{
							id = $('#pie2Td');
							title = "Pie Chart";
							var data_array = [];
							for(var k = 0; k < pie2_array.length; k++)
							{
								data_array.push({name:pie2_name[k],y:pie2_array[k]});
								
							}//insert dynamic object into array
							ydata = [{name:"Product price",data:data_array}];
							chartType = "pie";	
							drawHighChartBar(id,title,ydata,pie2_name,chartType,yAxis);
						}
						else
						{
							$('#pie2Td').remove(); //remove pie2Div to avoid override
							$('#td2').append('<div style="width:309px" id="pie2Td"></div>');
							$('#pie2Td').html("<center><small style='color:red'>No Record Between this range</small><center>");
						}
					
						var p1Len = pie1_array.length; 
						if(p1Len > 0)
						{
							id = $('#pie1Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];
                                                        for(var k = 0; k < pie1_array.length; k++)
                                                        {
                                                                data_array.push({name:pie1_name[k],y:pie1_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie1_name,chartType,yAxis);

						}
						else
						{
							$('#pie1Td').remove();
							$('#td1').append('<div style="width:309px;" id="pie1Td"></div>');
							$('#pie1Td').html("<center><small style='color:red'>No Record Between this range</small></center>");
						}

						var p3Len = pie3_array.length;
						if(p3Len > 0)
                                                {
                                                        id = $('#pie3Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];
                                                        for(var k = 0; k < pie3_array.length; k++)
                                                        {
                                                                data_array.push({name:pie3_name[k],y:pie3_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie3_name,chartType,yAxis);

                                                }
						else
						{	
							$('#pie3Td').remove();
							$('#td3').append('<div style="width:309px"; id="pie3Td"></div>');
							$('#pie3Td').html("<center><small style='color:red'>No Record Between this range</small></center>");
						}

					}//success function end here

				});//ajax end here
			}
			else
			{
				document.getElementById("alertSpan").innerHTML = "Drag and Drop From Option List"; 
			}

		} //generateGraph function end here
		
		function getData()
		{	
			document.getElementById("drop").value = "";
			document.getElementById("alertSpan").innerHTML = "";
			//$('#pieOnly').attr('checked',false);
			
			var finalVal = '';
			$('.check:checked').each(function(){
				var val = $(this).val();
				finalVal += val+",";
			}); //get value of all checked checkbox

			if(finalVal)
			{
				var finalD = finalVal.replace(/,\s*$/,""); //remove last ","
				var finalDate = finalD.replace(/-/g,"")//remove all "-"
	
				$.ajax({
					type:'GET',
					url:'joinData.php',
					contentType:'appliaction/json',
					dataType:'json',
					data:{"case":2,"dateVal":finalDate},
					success:function(resp){
						console.log(resp);			
						var Name = [];
						var Price = [];

						var pie1_array = [];
                                                var pie1_name = [];
                                                var pie2_array = [];
                                                var pie2_name = [];
                                                var pie3_array = [];
                                                var pie3_name = [];
						var prodPrice = 0;

						for(var j = 0; j < resp.length; j++)
						{
							Price.push(parseInt(resp[j]['price']));
							Name.push(resp[j]['customer_name']);	
							prodPrice = parseInt(resp[j]['price']);
							if(prodPrice >= 200 && prodPrice <= 300)
                                                        {
                                                                pie1_array.push(prodPrice);   
                                                                pie1_name.push(resp[j]['customer_name']);
                                                        }
                                                        else if(prodPrice >= 301 && prodPrice <= 400)
                                                        {
                                                                pie2_array.push(prodPrice);
                                                                pie2_name.push(resp[j]['customer_name']);
                                                        }
                                                        else
                                                        {
                                                                pie3_array.push(prodPrice);
                                                                pie3_name.push(resp[j]['customer_name']);
                                                        } 
						}
						console.log(pie1_array);
						console.log(pie2_array);
						console.log(pie3_array);
						var id = $('#barGraphTd');
						var title = "Bar Chart";
						var ydata = [{name:"Product Price",data:Price}];
						var chartType = "column";
						var yAxis = {
								min:0,
								max:500,
								title:{
									text:"Price (Rs)"	
								      }
							    };

						drawHighChartBar(id,title,ydata,Name,chartType,yAxis);//function call for bar chart
						id = $('#lineGraph');
						title = "Line Chart";
						chartType = "spline";
						drawHighChartBar(id,title,ydata,Name,chartType,yAxis);//function call for line chart
						//piechart start here
						if(pie1_array.length > 0)
                                                {
                                                        id = $('#pie1Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];

                                                        for(var k = 0; k < pie1_array.length; k++)
                                                        {
                                                                data_array.push({name:pie1_name[k],y:pie1_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie1_name,chartType,yAxis);

                                                }
						else
						{
							$('#pie1Td').remove();
							$('#td1').append('<div style="width:309px;overflow:hidden" id="pie1Td"></div>');
							$('#pie1Td').html("<center><small style='color:red'>No Record Between this range</small><center>");
						}

						var p2Len = pie2_array.length;
						if(p2Len > 0)
                                                {
                                                        id = $('#pie2Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];
                                                        for(var k = 0; k < pie2_array.length; k++)
                                                        {
                                                                data_array.push({name:pie2_name[k],y:pie2_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie2_name,chartType,yAxis);
                                                }
						else
						{
							$('#pie2Td').remove();
							$('#td2').append('<div style="width:309px;" id="pie2Td"></div>');
							$('#pie2Td').html("<center><small style='color:red'>No Record Between this range</small></center>");
						}

						var pie3Len = pie3_array.length
						if(pie3Len > 0)
                                                {
                                                        id = $('#pie3Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];

                                                        for(var k = 0; k < pie3_array.length; k++)
                                                        {
                                                                data_array.push({name:pie3_name[k],y:pie3_array[k]});
                                                                
                                                        }

                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie3_name,chartType,yAxis);

                                                }
						else
						{
							$('#pie3Td').remove();
							$('#td3').append('<div style="width:309px;" id="pie3Td"></div>');
							$('#pie3Td').html("<center><small style='color:red'>No Record Between this range</small></center>");
						
						}
						
					}//success function end here
					
				}); //ajax end here
			}
			else
			{
				
				window.location.reload();//relaod current page
				$('#pieOnly').attr('checked',false);
				$('#bothBar').attr('checked',false);
			}
		} //function getData end here

		function showPie() 
		{
			if($('#pieOnly').is(':checked'))
			{
				$('#bothBar').attr('checked',false);
				$('#barOnly').attr('checked',false);
				$('#r1').css('display','none');
				$('#r2').css('display','block');
				
				
			}
			else
			{
				$('#r1').css('display','block');
				$('#r2').css('display','none')
			
			}
			
		}

		function showBoth()
		{
			if($('#bothBar').is(':checked'))
			{
				$('#pieOnly').attr('checked',false);
				$('#barOnly').attr('checked',false);
				$('#r1').css('display','block');
				$('#r2').css('display','block');
			}
			else
			{
				$('#r2').css('display','none');
			}
		}

		function showBar()
		{
			if($('#barOnly').is(':checked'))
			{
				$('#pieOnly').attr('checked',false);
				$('#bothBar').attr('checked',false);
				
				$('#r1').css('display','block');
				$('#r2').css('display','none');
			}
			else
			{
				$('#r2').css('display','none');
			}
		}

        </script>

</head>
<body class="userSelect">
	<div id="outerDiv" class="outerDiv">
		<div id="optionDiv" class="optionDiv">
			<div id="dragOptionMainDiv" class="dragOptionMainDiv">
					<table class="dragOptionTable">
						<tr style="background-color:#CCFF99">
							<td align="center">Type Of Graph</td>
							<td align="center"><input class="barType" style="vertical-align:middle;" id="barOnly" onchange="showBar()" type="checkbox" value="bar"/> <small>Bar Graph</small> </td>
							<td align="center"><input class="barType" style="vertical-align:middle;" id="pieOnly" onchange="showPie()" type="checkbox" value="pie"/><small>Pie Chart</small></td>
							<td align="center"><input class="barType" style="vertical-align:middle;" id="bothBar" onchange="showBoth()" type="checkbox" value="both"/> <small>Both</small></td>
						</tr>
					</table>
                                        <table id="dragOptionTable"  border="1" class="dragOptionTable">
                                                <tr>
                                                        <th width="250px;height:30px">Drag Option List</th>
                                                        <th width="300px;height:30px">Drop Hrere</th>
                                                        <th style="height:30px">Date</th>
                                                </tr>
                                        </table>
					<table style="white-space:nowwrap">
					<tr>
					<td>
                                        	<div  id="dragOptionLeftDiv" style="height:80px;width:251px;border:1px solid grey;float:left;overflow:auto">
                                                	<ul id="Ulist">
                                                
                                                	</ul>
                                        
                                        	</div>
					</td>
					<td>
                                        	<div id="dragOptionMiddleDiv" style="height:80px;width:302px;border:1px solid grey;margin-left:-2px;float:left">
                                                	<input type="text" id="drop" ondrop="drop(event)" ondragover="allowDrop(event)" style="height:25px;width:250px;margin-top:18px;margin-left:20px;border-radius:10px" readonly/>
                                                 	<center><span id="alertSpan" style="color:red"></span></center>
                                        	</div>
					</td>
					<td style="white-space:nowrap">
						 <div id="dragOptionRightDiv"style="height:80px;width:230px;border:1px solid grey;overflow:auto;float:left;margin-left:-1px">
                                                
                                        	</div>
					</td>
					</tr>
					</table>
					 <center>
						<button id="btnOk" style="height:35px;width:150px;border-radius:8px;cursor:pointer;white-space:nowrap;background-color:green;color:white;" onclick="generateGraph()"> Generate</button>
					</center>
				</div><!--dragOptionDiv end here-->
		</div><!--optionDiv end here-->
		<div id="blankGraphDiv" class="blankGraphDiv">
			<table width="100%" height="100%" border="1" style="margin-top:20px">
				<tr id="r1" style="height:400px">
					<td  style="overflow:auto;">
						<div id="barGraphTd" style="width:945px">
						</div>
					</td>
				
				</tr>
				<tr id="r2" style="height:466px;display:none;white-space:nowrap">
                                   
					<td id="td1" class="pieTd">
						<h5 style="text-align:center">Price Range Between 200 to 300</h5>
						<div style="width:311px;overflow:hidden" id="pie1Td">
						
						</div>
						
					</td>
					<td  id="td2" class="pieTd">
						<div><h5 style="text-align:center">Price Range Between 301 to 400</h5></div>
						 <div style="width:310px" id="pie2Td">
                                                </div>
					</td>
					<td id="td3" class="pieTd">
						<h5 style="text-align:center">Price Range Between 401 to 500</h5>
						 <div style="width:311px" id="pie3Td">
                                                </div>
					</td>
                                </tr><!--end of 2nd tr -->
			</table>
		</div><!-- blankGraphDiv end here-->
	
	<div><!--outerDiv end here-->
</body>
</html>
