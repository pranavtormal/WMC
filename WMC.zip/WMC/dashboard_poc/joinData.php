<?php

//$case == 0 for onpage load
//$case == 1 to generate graph on the basis of customer id 
//$case == 2 to generate graph on the basis of date 
//$cid = customer id
//dateVal = date 
//-1 for not valid cid
 
include_once("dbconn.php");
header("Content-Type:application/json");
$out = array(); // output array

$case = trim($_GET['case']);
$cid = mysql_real_escape_string(strip_tags(trim($_GET['cid']))); //escape special charactets from i/p string
$dateVal = mysql_real_escape_string(strip_tags(trim($_GET['dateVal'])));
if($case == 0)
{
	$sql = "SELECT customer_id,order_date FROM orders";
	$sql1 = "SELECT orders.price,customers.customer_name FROM orders INNER JOIN customers ON orders.customer_id=customers.customer_id";
	$result = mysql_query($sql,$con);
	$result1 = mysql_query($sql1,$con); 
	if($result && $result1)
	{
		while($row = mysql_fetch_assoc($result))
		{
			$out['id'][] = $row;
		}
		while($row1 = mysql_fetch_assoc($result1))
		{
			$out['bar'][] = $row1;
		}
		echo json_encode($out);
	}
	else
	{
		echo json_encode("Query Error!");
	}
}
else if($case == 1 && $cid)
{
	if(preg_match('/^[0-9]{4}+$/',$cid) || preg_match('/^[0-9]{4}(,[0-9]{4}+$)/',$cid) )
	{
		$sql = "SELECT orders.price,customers.customer_name FROM orders INNER JOIN customers ON orders.customer_id=customers.customer_id WHERE orders.customer_id IN($cid)";
		$result = mysql_query($sql,$con);
		if($result)
		{
			while($row = mysql_fetch_assoc($result))
			{
				$out[] = $row;
			}
			echo json_encode($out);
		}
		else
		{
			echo json_encode("Query Error!");
		}
	}
	else
	{
		echo json_encode("-1");
	}
}
else if($case == 2 && $dateVal)
{
	$sql = "SELECT orders.price,customers.customer_name FROM orders INNER JOIN customers ON orders.customer_id=customers.customer_id WHERE orders.order_date IN($dateVal)";
	$result = mysql_query($sql,$con);
	if($result)
	{
		while($row = mysql_fetch_assoc($result))
		{
			$out[] =$row; 
		}
		echo json_encode($out);
	}
	else
	{
		echo json_encode("Query Error!");

	}	
}
else
{
	echo json_encode("Error!");
}

?>
