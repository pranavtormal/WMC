 $(document).ready(function(){
                       
                        $.ajax({
                                type:'GET',
                                url:'joinData.php',
                                contentType:'application/json',
                                dataType:'json',
                                data:{"case":0},
                                success:function(resp){
                                
                                        var name_array = [];
                                        var price_array = [];
                                        var date_array = []; //contains duplicates values
                                        var unique_date = []; //for unique date
                                        var price = 0;
                                        var pie1_array = []; //array for price range 200 to 300
                                        var pie1_name = []; 
                                        var pie2_array = []; //array for price range 301 to 400
                                        var pie2_name = [];
                                        var pie3_array = []; //array for price range 401 to 500
                                        var pie3_name = []; 

                                        for(var i = 0; i < resp.id.length; i++)
                                        {
                                                var id = resp.id[i]['customer_id'];
                                                date_array.push(resp.id[i]['order_date']);
                                                $('#Ulist').append('<li draggable="true" ondragstart="drag(event)" id="'+ id +'">'+id+'<li>');
                                                
                                        }
					                                        var unique_date = date_array.filter(function(ele,index,self){
                                                return index == self.indexOf(ele);
                                        });//remove duplicates
                                        
                                        for(var x = 0; x < unique_date.length; x++)
                                        {
                                                $('#dragOptionRightDiv').append('<center><input type="checkbox" onchange="getData()" style="vertical-align:middle;" class="check" value="'+unique_date[x]+'">'+unique_date[x]+'</center>');     
                                        }
                                        
                                        for(var j = 0; j < resp.bar.length; j++)
                                        {
                                                var price = parseInt(resp.bar[j]['price']);
                                                var name = resp.bar[j]['customer_name'];
                                                price_array.push(price);         
                                                name_array.push(name);
                                                 if(price >= 200 && price <= 300) //filter price range
                                                 {
                                                        pie1_array.push(price);   
                                                        pie1_name.push(name);
                                                 }
                                                 else if(price >= 301 && price <= 400)
                                                 {
                                                        pie2_array.push(price);
                                                        pie2_name.push(name);
                                                 }
                                                 else
                                                 {
                                                        pie3_array.push(price);
                                                        pie3_name.push(name);
                                                 }
                                        }
					//console.log(pie2_array);
                                        if(pie2_array.length > 0)
                                        {
                                                id = $('#pie2Td');
                                                title = "Pie Chart";
                                                var data_array = [];
                                                for(var k = 0; k < pie2_array.length; k++)
                                                {
                                                        data_array.push({name:pie2_name[k],y:pie2_array[k]});
                                                }//insert dynamic object into array
                                                ydata = [{name:"Product price",data:data_array}];
                                                chartType = "pie";      
                                                drawHighChartBar(id,title,ydata,pie2_name,chartType,yAxis);
                                        }
                                        if(pie1_array.length > 0)
                                        {
                                                id = $('#pie1Td');
                                                title = "Pie Chart";
                                                var data_array = [];
                                                for(var k = 0; k < pie1_array.length; k++)
                                                {
                                                        data_array.push({name:pie1_name[k],y:pie1_array[k]});
                                                                
                                                }
                                                ydata = [{name:"Product price",data:data_array}];
                                                chartType = "pie";      
                                               drawHighChartBar(id,title,ydata,pie1_name,chartType,yAxis);

                                         }
					if(pie3_array.length > 0)
                                        {
                                                id = $('#pie3Td');
                                                title = "Pie Chart";
                                                var data_array = [];
                                                for(var k = 0; k < pie3_array.length; k++)
                                                {
                                                        data_array.push({name:pie3_name[k],y:pie3_array[k]});
                                                                
                                                }//insert dynamic object into array
                                                ydata = [{name:"Product price",data:data_array}];
                                                chartType = "pie";      
                                               drawHighChartBar(id,title,ydata,pie3_name,chartType,yAxis);

                                         }

                                        function drawHighChartBar(id,Title,data,names,chartType,yAxis) //function to create Charts
                                        {
                                                $(id).highcharts({
                                                        chart:{
                                                                type:chartType,
								
                                                              },
                                                        title:{
                                                                text:Title
                                                              },
                                                        xAxis:{
                                                                categories:names,
                                                              },
                                                        yAxis,
                                                        legend:{
                                                                 reversed:true
                                                               },
                                                        series:data
                                                 });
                                        } //drawHighChartBar function end here 
					var tid = $('#barGraphTd');
                                        var title = "Bar Graph";
                                        var chartType = "column";
                                        var yAxis =  {
                                                        min:0,
                                                        title:{
                                                                text:'Price (Rs)'
                                                              } 
                                                     };

                                        var ydata = [{name:"Product Price",data:price_array}];

                                        drawHighChartBar(tid,title,ydata,name_array,chartType,yAxis);//function call for bar chart
                                        tid = $('#lineGraph');
                                        title = "Line Graph";
                                        chartType = "spline";
                                        drawHighChartBar(tid,title,ydata,name_array,chartType,yAxis);//function call for Line Chart
                                    
                                }//success function end here
                        });//ajax end here
                
                });//ready function end here
        
                 function allowDrop(ev) 
                {
                         ev.preventDefault(); 
                }

                function drag(ev)
                {
                        ev.dataTransfer.setData("text", ev.target.id); 
                }
		 function drop(ev) 
                {
                        ev.preventDefault();
                        var data = ev.dataTransfer.getData("text");
                        document.getElementById("drop").value += data + ','; 
                        document.getElementById(data).remove();                       
                }

                function drawHighChartBar(id,Title,data,names,chartType,yAxis)
                {
                        //var hwidth = $(id).parent().width();
                        $(id).highcharts({
                                        chart:{
                                                type:chartType
                                        
                                                //wiidth:300
                                              },
                                         plotOptions:{
                                                        pie:{
                                                                size: 140
                                                            }
                                                     },
                                        title:{
                                                text:Title
                                              },
                                        xAxis:{
                                                categories:names,
                                              },
                                        yAxis,
                                        legend:{
                                                reversed:true
                                                },
                                        series:data
                         });
                }
		function generateGraph()
                {
                        var col = document.getElementById('drop').value;
                        document.getElementById("alertSpan").innerHTML = "";
                        document.getElementById("drop").value = "";
                        $('.check').attr('checked',false); 
                        var col = col.trim();

                        if(col)
                        {
                                var str = col.replace(/,\s*$/,""); //remove last ","
                                var element = str.split(',');
                
                                for(var k = 0; k < element.length ; k++) //append dropped element
                                {
                                         $('#Ulist').append('<li draggable="true" ondragstart="drag(event)" id="'+ element[k]+'">'+element[k]+'<li>');

                                }

                                $.ajax({
                                        type:'GET',
                                        url:'joinData.php',
                                        contentType:'application/json',
                                        dataType:'json',
                                        data:{"case":1,"cid":str},
                                        success:function(response){
                                                console.log(response);
						console.log(response.length);
                                                var barVal = '';
                                                $('.barType:checked').each(function(){
                                                        var val = $(this).val();
                                                        barVal += val+",";
                                                });
                        
                                                var names_array = [];
                                                var price_array = [];
						var price = 0;
                                                var pie1_array = [];
                                                var pie1_name = [];
                                                var pie2_array = [];
                                                var pie2_name = [];
                                                var pie3_array = [];
                                                var pie3_name = [];

                                                for(var i = 0; i < response.length; i++)
                                                {
                                                        names_array.push(response[i]['customer_name']);
                                                        price_array.push(parseInt(response[i]['price']));
                                                        price = parseInt(response[i]['price']);
                                                        
                                                        if(price >= 200 && price <= 300)
                                                        {
                                                                pie1_array.push(price);   
                                                                pie1_name.push(response[i]['customer_name']);
                                                        }
                                                        else if(price >= 301 && price <= 400)
                                                        {
                                                                pie2_array.push(price);
                                                                pie2_name.push(response[i]['customer_name']);
                                                        }
                                                        else
                                                        {
                                                                pie3_array.push(price);
                                                                pie3_name.push(response[i]['customer_name']);
                                                        }
                                                }
                                        
                                                var id = $('#barGraphTd');
                                                var title = "Bar Graph";
                                                var ydata = [{name:"Product Price",data:price_array}];
                                                var chartType = "column";
                                                var id = $('#barGraphTd');
                                                var title = "Bar Graph";
                                                var ydata = [{name:"Product Price",data:price_array}];
                                                var chartType = "column";
						var yAxis ={
                                                                min:0,
                                                                max:500,
                                                                title:{
                                                                        text:'Price (Rs)'
                                                                      } 
                                                           };

                                                drawHighChartBar(id,title,ydata,names_array,chartType,yAxis); //function call for bar chart
                                             
                                                //pieChart start here
                                                if(pie2_array.length > 0)
                                                {
                                                        id = $('#pie2Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];
                                                        for(var k = 0; k < pie2_array.length; k++)
                                                        {
                                                                data_array.push({name:pie2_name[k],y:pie2_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie2_name,chartType,yAxis);
                                                }
						else
                                                {
                                                        $('#pie2Td').remove(); //remove pie2Div to avoid override
                                                        $('#td2').append('<div style="width:309px" id="pie2Td"></div>');
                                                        $('#pie2Td').html("<center><small style='color:red'>No Record Between this range</small><center>");
                                                }
                                        
                                                var p1Len = pie1_array.length; 
                                                if(p1Len > 0)
                                                {
                                                        id = $('#pie1Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];
                                                        for(var k = 0; k < pie1_array.length; k++)
                                                        {
                                                                data_array.push({name:pie1_name[k],y:pie1_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie1_name,chartType,yAxis);

                                                }
                                                else
                                                {
                                                        $('#pie1Td').remove();
                                                        $('#td1').append('<div style="width:309px;" id="pie1Td"></div>');
                                                        $('#pie1Td').html("<center><small style='color:red'>No Record Between this range</small></center>");
                                                }
						var p3Len = pie3_array.length;
                                                if(p3Len > 0)
                                                {
                                                        id = $('#pie3Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];
                                                        for(var k = 0; k < pie3_array.length; k++)
                                                        {
                                                                data_array.push({name:pie3_name[k],y:pie3_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie3_name,chartType,yAxis);

                                                }
                                                else
                                                {       
                                                        $('#pie3Td').remove();
                                                        $('#td3').append('<div style="width:309px"; id="pie3Td"></div>');
                                                        $('#pie3Td').html("<center><small style='color:red'>No Record Between this range</small></center>");
                                                }

                                        }//success function end here

                                });//ajax end here
                        }
                        else
                        {
                                document.getElementById("alertSpan").innerHTML = "Drag and Drop From Option List"; 
                        }
			} //generateGraph function end here
                
                function getData()
                {       
                        document.getElementById("drop").value = "";
                        document.getElementById("alertSpan").innerHTML = "";
                        //$('#pieOnly').attr('checked',false);
                        
                        var finalVal = '';
                        $('.check:checked').each(function(){
                                var val = $(this).val();
                                finalVal += val+",";
                        }); //get value of all checked checkbox

                        if(finalVal)
                        {
                                var finalD = finalVal.replace(/,\s*$/,""); //remove last ","
                                var finalDate = finalD.replace(/-/g,"")//remove all "-"
        
                                $.ajax({
                                        type:'GET',
                                        url:'joinData.php',
                                        contentType:'application/json',
                                        dataType:'json',
                                        data:{"case":2,"dateVal":finalDate},
                                        success:function(resp){
                                                //console.log(resp);                      
                                                var Name = [];
                                                var Price = [];

                                                var pie1_array = [];
                                                var pie1_name = [];
                                                var pie2_array = [];
                                                var pie2_name = [];
						var pie3_array = [];
                                                var pie3_name = [];
                                                var prodPrice = 0;

                                                for(var j = 0; j < resp.length; j++)
                                                {
                                                        Price.push(parseInt(resp[j]['price']));
                                                        Name.push(resp[j]['customer_name']);    
                                                        prodPrice = parseInt(resp[j]['price']);
                                                        if(prodPrice >= 200 && prodPrice <= 300)
                                                        {
                                                                pie1_array.push(prodPrice);   
                                                                pie1_name.push(resp[j]['customer_name']);
                                                        }
                                                        else if(prodPrice >= 301 && prodPrice <= 400)
                                                        {
                                                                pie2_array.push(prodPrice);
                                                                pie2_name.push(resp[j]['customer_name']);
                                                        }
                                                        else
                                                        {
                                                                pie3_array.push(prodPrice);
                                                                pie3_name.push(resp[j]['customer_name']);
                                                        } 
                                                }
                                                //console.log(pie1_array);
                                                //console.log(pie2_array);
                                                //console.log(pie3_array);
                                                var id = $('#barGraphTd');
                                                var title = "Bar Chart";
                                                var ydata = [{name:"Product Price",data:Price}];
                                                var chartType = "column";
                                                var yAxis = {
                                                                min:0,
                                                                max:500,
                                                                title:{
                                                                        text:"Price (Rs)"       
                                                                      }
                                                            };
						drawHighChartBar(id,title,ydata,Name,chartType,yAxis);//function call for bar chart
                                                id = $('#lineGraph');
                                                title = "Line Chart";
                                                chartType = "spline";
                                                drawHighChartBar(id,title,ydata,Name,chartType,yAxis);//function call for line chart
                                                //piechart start here
                                                if(pie1_array.length > 0)
                                                {
                                                        id = $('#pie1Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];

                                                        for(var k = 0; k < pie1_array.length; k++)
                                                        {
                                                                data_array.push({name:pie1_name[k],y:pie1_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie1_name,chartType,yAxis);

                                                }
                                                else
                                                {
                                                        $('#pie1Td').remove();
                                                        $('#td1').append('<div style="width:309px;overflow:hidden" id="pie1Td"></div>');
                                                        $('#pie1Td').html("<center><small style='color:red'>No Record Between this range</small><center>");
                                                }
						var p2Len = pie2_array.length;
                                                if(p2Len > 0)
                                                {
                                                        id = $('#pie2Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];
                                                        for(var k = 0; k < pie2_array.length; k++)
                                                        {
                                                                data_array.push({name:pie2_name[k],y:pie2_array[k]});
                                                                
                                                        }//insert dynamic object into array
                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie2_name,chartType,yAxis);
                                                }
                                                else
                                                {
                                                        $('#pie2Td').remove();
                                                        $('#td2').append('<div style="width:309px;" id="pie2Td"></div>');
                                                        $('#pie2Td').html("<center><small style='color:red'>No Record Between this range</small></center>");
                                                }
						var pie3Len = pie3_array.length
                                                if(pie3Len > 0)
                                                {
                                                        id = $('#pie3Td');
                                                        title = "Pie Chart";
                                                        var data_array = [];

                                                        for(var k = 0; k < pie3_array.length; k++)
                                                        {
                                                                data_array.push({name:pie3_name[k],y:pie3_array[k]});
                                                                
                                                        }

                                                        ydata = [{name:"Product price",data:data_array}];
                                                        chartType = "pie";      
                                                        drawHighChartBar(id,title,ydata,pie3_name,chartType,yAxis);

                                                }
                                                else
                                                {
                                                        $('#pie3Td').remove();
                                                        $('#td3').append('<div style="width:309px;" id="pie3Td"></div>');
                                                        $('#pie3Td').html("<center><small style='color:red'>No Record Between this range</small></center>");
                                                
                                                }
						 }//success function end here
                                        
                                }); //ajax end here
                        }
                        else
                        {
                                
                                window.location.reload();//relaod current page
                                $('#pieOnly').attr('checked',false);
                                $('#bothBar').attr('checked',false);
                        }
                } //function getData end here

                function showPie() 
                {
                        if($('#pieOnly').is(':checked'))
                        {
                                $('#bothBar').attr('checked',false);
                                $('#barOnly').attr('checked',false);
                                $('#r1').css('display','none');
                                $('#r2').css('display','block');
                                
                                
                        }
                        else
                        {
                                $('#r1').css('display','block');
                                $('#r2').css('display','none')
                        
                        }
                        
                }
		 function showBoth()
                {
                        if($('#bothBar').is(':checked'))
                        {
                                $('#pieOnly').attr('checked',false);
                                $('#barOnly').attr('checked',false);
                                $('#r1').css('display','block');
                                $('#r2').css('display','block');
                        }
                        else
                        {
                                $('#r2').css('display','none');
                        }
                }

                function showBar()
                {
                        if($('#barOnly').is(':checked'))
                        {
                                $('#pieOnly').attr('checked',false);
                                $('#bothBar').attr('checked',false);
                                
                                $('#r1').css('display','block');
                                $('#r2').css('display','none');
                        }
                        else
                        {
                                $('#r2').css('display','none');
                        }
                }
