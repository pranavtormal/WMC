<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<script src="jquery-1.7.1.min.js"></script>
		<script>
			$(document).ready(function(){ 
                        	$.ajax({
                                	type:'GET',
                                	url:'tableData.php',
                                	contentType:'appliaction/json',
                                	dataType:'json',
                               		data:{"case":0},
                                	success:function(resp){
						
						var tableName = [];
						var divId = 0;//id for Div
						for(var i = 0; i < resp.length; i++)
						{
							if(i == 0)
							{
								
								$('#tableInfoDiv').append('<div id="'+divId+'" style="width:300px;border:1px solid grey;"> Table Name:-'+resp[i]['table_name']+'<br/>'+resp[i]['column_name']+'<br/></div>'); 
								
							}
							else if(resp[i-1]['table_name'] == resp[i]['table_name'])
							{	
									
								$('#'+divId).append(resp[i]['column_name']+'<br/>');
							}
							else
							{
								
								divId = divId +1; 
								$('#tableInfoDiv').append('<br/><div id="'+ divId+'" style="width:300px;border:1px solid grey;"> Table Name:-'+resp[i]['table_name']+'<br/>'+resp[i]['column_name']+'<br/></div>');	
							
							}
						}
						/*
						var  name_array = tableName.filter(function(ele,index,self){
                                                return index == self.indexOf(ele);
                                        	});//remove duplicates
						//console.log(name_array);
						*/
								
					}	
				});
			});
		
		</script>
	</head>
<body>
	<div id="tableInfoDiv" style="border:10px solid #EDF6E1;">
	
	</div>
</body>
</html>
